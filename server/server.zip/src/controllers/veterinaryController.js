const { db } = require('../database');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
dotenv.config();

const sendPasswordEmail = async (correo, password) => {
    const transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
            user: process.env.MAIL,
            pass: process.env.PASSWORD
        }
    });


    const mailOptions = {
        from: `"SOPORTE EQUINO" <${process.env.MAIL}>`,
        to: correo,
        subject: 'Bienvenido a Soporte Equino',
        text: `Hola, tu contraseña por defecto es: ${password}`,
        html: `
        <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                    }
                    .header {
                        background-color: #f1f1f1;
                        padding: 10px;
                        text-align: center;
                    }
                    .content {
                        margin: 20px;
                    }
                    .footer {
                        font-size: 12px;
                        color: #888;
                        text-align: center;
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>Bienvenido a Soporte Equino</h1>
                </div>
                <div class="content">
                    <p>Hola,</p>
                    <p>Gracias por registrarte en nuestro servicio. Estamos encantados de tenerte con nosotros.</p>
                </div>
                <div class="footer">
                    <p>Este es un correo automático, por favor no respondas.</p>
                    <p>Tu contraseña por defecto es: <strong>${password}</strong></p>
                </div>
            </body>
        </html> 
    `
    };

    // Envía el correo
    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('✅ Correo enviado exitosamente:', info.messageId);
    } catch (error) {
        console.error('❌ Error detallado al enviar correo:', {
            code: error.code,
            command: error.command,
            response: error.response,
            message: error.message
        });
    }
};

function generatePassword(longitud = 10) {
    const caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+[]{}|;:,.<>?';
    let password = '';
    for (let i = 0; i < longitud; i++) {
        const indice = Math.floor(Math.random() * caracteres.length);
        password += caracteres[indice];
    }
    return password;
}

const getVeterinarys = async () => {
    const [result] = await db.query(`
        SELECT * FROM veterinario
    `)
    const veterinariosConFoto = result.map(veterinario => {
        if (veterinario.Foto && Buffer.isBuffer(veterinario.Foto)) {
            const fotoStr = veterinario.Foto.toString('utf8');
            if (fotoStr.startsWith('/uploads/') || fotoStr.startsWith('http') || fotoStr.startsWith('data:image/')) {
                veterinario.Foto = fotoStr;
            } else {
                const base64String = veterinario.Foto.toString('base64');
                veterinario.Foto = `data:image/jpeg;base64,${base64String}`;
            }
        }
        // Si ya es una URL/ruta (empieza con /uploads), se deja igual
        return veterinario;
    });
    return veterinariosConFoto;
}

const getVeterinarystatus = async () => {
    const [result] = await db.query(`
        SELECT * FROM veterinario WHERE estado = 'Activo'
    `)
    const veterinariosConFoto = result.map(veterinario => {
        if (veterinario.Foto && Buffer.isBuffer(veterinario.Foto)) {
            const fotoStr = veterinario.Foto.toString('utf8');
            if (fotoStr.startsWith('/uploads/') || fotoStr.startsWith('http') || fotoStr.startsWith('data:image/')) {
                veterinario.Foto = fotoStr;
            } else {
                const base64String = veterinario.Foto.toString('base64');
                veterinario.Foto = `data:image/jpeg;base64,${base64String}`;
            }
        }
        return veterinario;
    });
    return veterinariosConFoto;
}

const getVeterinaryById = async (idVeterinario) => {
    const [result] = await db.query(`
        SELECT * FROM veterinario WHERE idVeterinario = ?
    `,
        [idVeterinario]
    )
    if (result.length > 0 && result[0].Foto && Buffer.isBuffer(result[0].Foto)) {
        const fotoStr = result[0].Foto.toString('utf8');
        if (fotoStr.startsWith('/uploads/') || fotoStr.startsWith('http') || fotoStr.startsWith('data:image/')) {
            result[0].Foto = fotoStr;
        } else {
            const base64String = result[0].Foto.toString('base64');
            result[0].Foto = `data:image/jpeg;base64,${base64String}`;
        }
    }
    return result;
};

const createVeterinary = async (Cedula, Nombre, Apellido, Correo, Descripcion, Especialidad, Foto, Redes, Rol = 'Veterinario') => {
    const password = generatePassword();
    const Contraseña = await bcrypt.hash(password, 10);

    const result = await db.query(`
        INSERT INTO veterinario (Cedula, Nombre, Apellido, Correo, Descripcion, Especialidad, Contraseña, Foto, Redes, Rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
        [Cedula, Nombre, Apellido, Correo, Descripcion, Especialidad, Contraseña, Foto, Redes, Rol]
    );
    await sendPasswordEmail(Correo, password); // Enviar correo con la contraseña
    return result;
}

const updateVeterinary = async (idVeterinario, Cedula, Nombre, Apellido, Correo, Descripcion, Especialidad, Foto, Estado, Redes, Contraseña, Rol) => {
    // Usar nombres de columnas consistentes con la base de datos
    let sql = `UPDATE veterinario SET Cedula = ?, Nombre = ?, Apellido = ?, Correo = ?, Descripcion = ?, Especialidad = ?, Foto = ?, Redes = ?`;
    const params = [Cedula, Nombre, Apellido, Correo, Descripcion, Especialidad, Foto, Redes];

    // Manejar Estado de forma segura
    if (Estado !== undefined) {
        sql += `, Estado = ?`;
        params.push(Estado);
    }

    if (Rol !== undefined) {
        sql += `, Rol = ?`;
        params.push(Rol);
    }

    if (Contraseña) {
        const hashedPassword = await bcrypt.hash(Contraseña, 10);
        sql += `, Contraseña = ?`;
        params.push(hashedPassword);
    }

    sql += ` WHERE idVeterinario = ?`;
    params.push(idVeterinario);

    const [result] = await db.query(sql, params);
    return result;
}

const deleteVeterinary = async (idVeterinario) => {
    const result = await db.query(`
        DELETE FROM veterinario WHERE idVeterinario = ?
    `,
        [idVeterinario]
    );
    return result;
}

module.exports = {
    getVeterinarys,
    getVeterinarystatus,
    getVeterinaryById,
    createVeterinary,
    updateVeterinary,
    deleteVeterinary
}